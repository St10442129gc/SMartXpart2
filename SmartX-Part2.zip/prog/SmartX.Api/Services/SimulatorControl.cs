namespace SmartX.Api.Services;

public record SimulatorScenario(Guid Id, string Type, string? MacAddress, int? Count, DateTime RequestedUtc);

public record ScenarioRequest(string Type, string? MacAddress = null, int? Count = null);

/// <summary>
/// A mailbox between the dashboard's "test bench" buttons and the separate SmartX.DeviceSimulator process.
///
/// The API never fabricates telemetry itself. When you press "Inject power spike" the request is parked here;
/// the simulator polls for it and then sends the spike as genuine device HTTP traffic, so it goes through
/// exactly the same ingestion, triage and queueing path a real ESP32 would.
/// </summary>
public class SimulatorControl
{
    public static readonly string[] ScenarioTypes =
    {
        "PowerSpike",           // one smart plug reports a severe overload
        "MoistureDrop",         // one moisture sensor dries out quickly below 20%
        "Disconnect",           // a node stops reporting and sends a single link-lost alert
        "DuplicateDisconnects", // a node floods 5 identical link-lost alerts (HashSet suppresses 4)
        "Burst",                // every device fires a flood of ordinary readings at once
        "BurstWithSpike",       // a flood of ordinary readings with one critical spike at the end
        "Reconnect",            // bring every disconnected node back online
        "Reset"                 // restore all simulated sensors to healthy baselines
    };

    private readonly Queue<SimulatorScenario> _pending = new();
    private readonly LinkedList<SimulatorScenario> _recent = new();
    private readonly object _lock = new();
    private DateTime? _lastPollUtc;

    public SimulatorScenario? Request(ScenarioRequest request)
    {
        var type = ScenarioTypes.FirstOrDefault(t => t.Equals(request.Type, StringComparison.OrdinalIgnoreCase));
        if (type is null) return null;

        var scenario = new SimulatorScenario(Guid.NewGuid(), type, request.MacAddress, request.Count, DateTime.UtcNow);
        lock (_lock)
        {
            _pending.Enqueue(scenario);
            _recent.AddFirst(scenario);
            while (_recent.Count > 20) _recent.RemoveLast();
        }
        return scenario;
    }

    /// <summary>Called by the simulator. Hands over every waiting scenario in the order it was requested.</summary>
    public List<SimulatorScenario> TakePending()
    {
        lock (_lock)
        {
            _lastPollUtc = DateTime.UtcNow;
            var list = new List<SimulatorScenario>();
            while (_pending.TryDequeue(out var s)) list.Add(s);
            return list;
        }
    }

    public object Status()
    {
        lock (_lock)
        {
            var connected = _lastPollUtc is not null && DateTime.UtcNow - _lastPollUtc < TimeSpan.FromSeconds(6);
            return new
            {
                SimulatorConnected = connected,
                LastPollUtc = _lastPollUtc,
                Waiting = _pending.Count,
                Recent = _recent.Take(8).ToList(),
                ScenarioTypes
            };
        }
    }
}
