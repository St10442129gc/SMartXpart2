using SmartX.Api.Services.CommandStream;

namespace SmartX.Api.Services.Insights;

/// <summary>
/// Ordinary least-squares line fit over a device's recent history, used to forecast WHEN a
/// sensor will breach its safe band so the dashboard can warn before it actually happens.
/// </summary>
public static class TrendPredictor
{
    public record Trend(double SlopePerSecond, double LatestValue, int Points);

    /// <summary>Fits value = a + b*t (t in seconds). Needs at least 5 points spanning 5+ seconds to be trustworthy.</summary>
    public static Trend? Fit(IReadOnlyList<TelemetryHistory.HistoryPoint> points)
    {
        if (points.Count < 5) return null;

        var t0 = points[0].TimestampUtc;
        var span = (points[^1].TimestampUtc - t0).TotalSeconds;
        if (span < 5) return null;

        double n = points.Count, sumT = 0, sumV = 0, sumTT = 0, sumTV = 0;
        foreach (var p in points)
        {
            var t = (p.TimestampUtc - t0).TotalSeconds;
            sumT += t; sumV += p.Value; sumTT += t * t; sumTV += t * p.Value;
        }

        var denominator = n * sumTT - sumT * sumT;
        if (Math.Abs(denominator) < 1e-9) return null;

        var slope = (n * sumTV - sumT * sumV) / denominator;
        return new Trend(slope, points[^1].Value, points.Count);
    }

    /// <summary>
    /// Fits the whole window, then re-fits just the newest readings and only trusts the trend if both agree.
    /// Without this, a sensor that ramped up and has since levelled off (e.g. a fully watered bed sitting at
    /// its cap) would still be "predicted" to keep rising because the old ramp dominates the long fit.
    /// </summary>
    public static Trend? FitConfirmed(IReadOnlyList<TelemetryHistory.HistoryPoint> points, int recentCount = 5)
    {
        var overall = Fit(points);
        if (overall is null || points.Count < recentCount + 2) return null;

        var recent = Fit(points.Skip(points.Count - recentCount).ToList());
        if (recent is null) return null;

        var sameDirection = Math.Sign(recent.SlopePerSecond) == Math.Sign(overall.SlopePerSecond);
        var stillMoving = Math.Abs(recent.SlopePerSecond) >= Math.Abs(overall.SlopePerSecond) * 0.3;
        return sameDirection && stillMoving ? overall : null;
    }

    /// <summary>Seconds until the trend line crosses <paramref name="limit"/>, or null if it is moving away from it.</summary>
    public static double? SecondsUntilBelow(Trend trend, double limit) =>
        trend.SlopePerSecond < 0 && trend.LatestValue > limit
            ? (trend.LatestValue - limit) / -trend.SlopePerSecond
            : null;

    public static double? SecondsUntilAbove(Trend trend, double limit) =>
        trend.SlopePerSecond > 0 && trend.LatestValue < limit
            ? (limit - trend.LatestValue) / trend.SlopePerSecond
            : null;
}
