using Microsoft.Extensions.Options;
using SmartX.Api.Models;
using SmartX.Api.Services.CommandStream;

namespace SmartX.Api.Services.Insights;

public enum OperatorEventKind { Search, Command }

/// <summary>Something the operator did - the raw material the engine learns from.</summary>
public record OperatorEvent(DateTime Utc, OperatorEventKind Kind, string ActionKey, string Label,
    string? DeviceMac, string? CommandAction, bool IsSample = false);

public record Suggestion(
    string Id,
    string Kind,          // "SuggestedAction" or "AutomatedInsight"
    string Title,
    string Detail,
    string Basis,         // which algorithm produced it - shown in the UI
    double Score,
    AlertLevel Level,
    string? DeviceMac,
    string? CommandAction,
    string? SearchTerm);

public record LearnedPattern(string When, string ThenAction, int Count, int Episodes, double Confidence);

public record InsightsResult(
    List<Suggestion> SuggestedActions,
    List<Suggestion> AutomatedInsights,
    List<string> HighlightedDevices,
    List<LearnedPattern> LearnedPatterns,
    List<OperatorEvent> RecentOperatorEvents);

// =====================================================================
// ASSIGNMENT REQUIREMENT (PART 2): PREDICTIVE ACTION & RECOMMENDATION ENGINE
//
// 1. PATTERN ANALYSIS - condition -> action association rules.
//    Every time the operator searches for a device or issues a command,
//    the engine credits that action to every fault condition that is
//    still active at that moment - i.e. what was wrong when they acted. Over repeated episodes it
//    learns rules such as
//        "Moisture Sensor B < 20%"  ->  "search Pump A", "start Pump A"
//    with confidence = times the action followed the condition
//                      / times the condition occurred.
//
// 2. SEQUENCE ANALYSIS - a first-order Markov chain of operator actions
//    (action -> next action counts) so that after one step the engine
//    can suggest the step that usually follows it.
//
// 3. AUTOMATED INSIGHTS - data-pattern checks that need no training:
//    offline nodes (HashSet), active critical faults, a least-squares
//    trend forecast over the SortedDictionary history that predicts a
//    breach BEFORE it happens, and recurring spike detection.
//
// All candidates are ranked through a PriorityQueue<Suggestion, double>
// (max-score first) so only the most relevant few reach the dashboard.
// =====================================================================
public class ActionInsightsEngine
{
    private static readonly TimeSpan SequenceWindow = TimeSpan.FromMinutes(3);
    private static readonly TimeSpan DismissFor = TimeSpan.FromMinutes(5);
    private const int MinSupport = 2;          // a pattern must be seen at least twice before it is suggested
    private const int MaxRecentEvents = 100;

    // condition key ("MAC:FaultCode") -> how many separate episodes of that condition there have been
    private readonly Dictionary<string, int> _episodes = new();

    // condition key -> (action key -> times that action followed the condition)
    private readonly Dictionary<string, Dictionary<string, int>> _conditionToAction = new();

    // action key -> (next action key -> count): the Markov transition table
    private readonly Dictionary<string, Dictionary<string, int>> _transitions = new();

    // condition key -> actions already credited during the CURRENT episode, so searching
    // "Pump A" five times during one moisture drop still only counts once.
    private readonly Dictionary<string, HashSet<string>> _creditedThisEpisode = new();

    private readonly Dictionary<string, OperatorEvent> _actionCatalog = new();
    private readonly Dictionary<string, DateTime> _dismissedUntil = new();
    private readonly LinkedList<OperatorEvent> _recentEvents = new();
    private readonly object _lock = new();

    private readonly DeviceRegistry _registry;
    private readonly FaultTracker _faults;
    private readonly TelemetryHistory _history;
    private readonly IOptionsMonitor<CommandStreamOptions> _options;

    public ActionInsightsEngine(DeviceRegistry registry, FaultTracker faults, TelemetryHistory history,
        IOptionsMonitor<CommandStreamOptions> options)
    {
        _registry = registry;
        _faults = faults;
        _history = history;
        _options = options;
    }

    public static string ConditionKey(string mac, FaultCode code) => $"{mac}:{code}";

    // -----------------------------------------------------------------
    // Learning inputs
    // -----------------------------------------------------------------

    /// <summary>The stream processor calls this when a fault is newly raised - that is the start of an episode.</summary>
    public void OnConditionStarted(string mac, FaultCode code, DateTime atUtc)
    {
        var key = ConditionKey(mac, code);
        lock (_lock)
        {
            _episodes[key] = _episodes.GetValueOrDefault(key) + 1;
            _creditedThisEpisode[key] = new HashSet<string>();
        }
    }

    public OperatorEvent RecordSearch(string term)
    {
        var device = _registry.FindByNameOrMac(term);
        var ev = device is not null
            ? new OperatorEvent(DateTime.UtcNow, OperatorEventKind.Search, $"find:{device.MacAddress}",
                $"Search \"{device.Name}\"", device.MacAddress, null)
            : new OperatorEvent(DateTime.UtcNow, OperatorEventKind.Search, $"search:{term.Trim().ToLowerInvariant()}",
                $"Search \"{term.Trim()}\"", null, null);
        Learn(ev);
        return ev;
    }

    public void RecordCommand(CommandRecord command)
    {
        var key = $"cmd:{command.TargetMac ?? "*"}:{command.Action}";
        Learn(new OperatorEvent(command.IssuedUtc, OperatorEventKind.Command, key, command.Label,
            command.TargetMac, command.Action));
    }

    private void Learn(OperatorEvent ev)
    {
        // Read fault state BEFORE taking our own lock so we never hold two locks at once.
        var activeConditions = _faults.ActiveFaults().Select(f => ConditionKey(f.MacAddress, f.Code)).ToHashSet();

        lock (_lock)
        {
            foreach (var cond in activeConditions)
            {
                // Ignore an operator "responding" to a fault on the very device they are acting on by searching
                // for it - that is just looking at the alert, not a learned response.
                if (ev.Kind == OperatorEventKind.Search && ev.DeviceMac is not null && cond.StartsWith(ev.DeviceMac + ":"))
                    continue;

                if (!_creditedThisEpisode.TryGetValue(cond, out var credited))
                {
                    credited = new HashSet<string>();
                    _creditedThisEpisode[cond] = credited;
                    // A condition we never saw start (e.g. it began before the API restarted) still counts as one episode.
                    _episodes[cond] = Math.Max(1, _episodes.GetValueOrDefault(cond));
                }
                if (!credited.Add(ev.ActionKey)) continue; // already counted for this episode

                Increment(_conditionToAction, cond, ev.ActionKey);
            }

            // Markov chain: credit the transition from the previous action to this one.
            var previous = _recentEvents.First?.Value;
            if (previous is not null && previous.ActionKey != ev.ActionKey && ev.Utc - previous.Utc <= SequenceWindow)
                Increment(_transitions, previous.ActionKey, ev.ActionKey);

            _actionCatalog[ev.ActionKey] = ev;
            _recentEvents.AddFirst(ev);
            while (_recentEvents.Count > MaxRecentEvents) _recentEvents.RemoveLast();
        }
    }

    public void Dismiss(string suggestionId)
    {
        lock (_lock) _dismissedUntil[suggestionId] = DateTime.UtcNow + DismissFor;
    }

    // -----------------------------------------------------------------
    // Output
    // -----------------------------------------------------------------

    public InsightsResult GetInsights(int maxPerList = 5)
    {
        var now = DateTime.UtcNow;
        var faults = _faults.ActiveFaults();
        var devices = _registry.All().ToDictionary(d => d.MacAddress, StringComparer.OrdinalIgnoreCase);

        // Max-first ranking: PriorityQueue is a min-heap, so enqueue with the negated score.
        var actionQueue = new PriorityQueue<Suggestion, double>();
        var insightQueue = new PriorityQueue<Suggestion, double>();
        var highlighted = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        List<LearnedPattern> patterns;
        List<OperatorEvent> recent;

        lock (_lock)
        {
            // ---- 1. Learned condition -> action rules for faults active right now ----
            foreach (var fault in faults)
            {
                var cond = ConditionKey(fault.MacAddress, fault.Code);
                if (!_conditionToAction.TryGetValue(cond, out var actions)) continue;
                var episodes = Math.Max(1, _episodes.GetValueOrDefault(cond));
                var conditionLabel = ConditionLabel(cond, devices);

                foreach (var (actionKey, count) in actions)
                {
                    if (count < MinSupport || !_actionCatalog.TryGetValue(actionKey, out var example)) continue;
                    if (IsAlreadySatisfied(example, devices)) continue;

                    var confidence = Math.Min(1.0, (double)count / episodes);
                    var s = BuildActionSuggestion($"rule:{cond}>{actionKey}", example, devices,
                        $"{conditionLabel}. You did this in {count} of the {episodes} times it has happened.",
                        "Pattern analysis (condition → action rule)",
                        0.5 + 0.5 * confidence, fault.Code == FaultCode.Disconnected ? AlertLevel.Warning : AlertLevel.Critical);
                    if (s is not null) actionQueue.Enqueue(s, -s.Score);
                }
            }

            // ---- 2. Markov next step after the operator's most recent action ----
            var last = _recentEvents.FirstOrDefault(e => !e.IsSample);
            if (last is not null && now - last.Utc <= SequenceWindow && _transitions.TryGetValue(last.ActionKey, out var next))
            {
                var total = next.Values.Sum();
                foreach (var (actionKey, count) in next)
                {
                    var probability = (double)count / total;
                    if (count < MinSupport || probability < 0.4 || !_actionCatalog.TryGetValue(actionKey, out var example)) continue;
                    if (IsAlreadySatisfied(example, devices)) continue;

                    var s = BuildActionSuggestion($"seq:{last.ActionKey}>{actionKey}", example, devices,
                        $"After \"{last.Label}\" you usually do this next ({probability:P0} of {total} times).",
                        "Sequence analysis (Markov chain)", 0.4 + 0.4 * probability, AlertLevel.None);
                    if (s is not null) actionQueue.Enqueue(s, -s.Score);
                }
            }

            // ---- 3c. Recurring problems, from the episode counts ----
            foreach (var (cond, count) in _episodes)
            {
                if (count < 3) continue;
                var mac = cond[..cond.LastIndexOf(':')];
                if (!devices.TryGetValue(mac, out var d)) continue;
                insightQueue.Enqueue(new Suggestion($"recurring:{cond}", "AutomatedInsight",
                    $"{d.Name} keeps faulting",
                    $"{ConditionLabel(cond, devices)} has happened {count} times since the gateway started. Worth a physical inspection.",
                    "Recurring-fault detection", 0.45, AlertLevel.Warning, mac, null, d.Name), -0.45);
            }

            patterns = BuildPatternTable(devices);
            recent = _recentEvents.Take(15).ToList();
        }

        // ---- 3a. Active faults and offline nodes ----
        foreach (var f in faults)
        {
            if (!devices.TryGetValue(f.MacAddress, out var d)) continue;
            highlighted.Add(d.MacAddress);
            var (score, level, title) = f.Code switch
            {
                FaultCode.Disconnected => (0.95, AlertLevel.Critical, $"{d.Name} is offline"),
                FaultCode.PowerSpike => (0.9, AlertLevel.Critical, $"Power spike on {d.Name}"),
                FaultCode.CriticalMoisture => (0.9, AlertLevel.Critical, $"{d.Name} critically dry"),
                _ => (0.7, AlertLevel.Warning, $"{d.Name} out of range")
            };
            var age = now - f.SinceUtc;
            insightQueue.Enqueue(new Suggestion($"fault:{f.MacAddress}:{f.Code}", "AutomatedInsight", title,
                $"{f.Message} (for {FormatAge(age)}).", "Live fault set (HashSet)", score, level, d.MacAddress, null, d.Name), -score);
        }

        // ---- 3b. Trend forecast: warn BEFORE a sensor leaves its safe band ----
        foreach (var d in devices.Values)
        {
            if (!d.IsOnline || d.Kind is not (DeviceKind.MoistureSensor or DeviceKind.TemperatureSensor or DeviceKind.SmartPlug)) continue;

            var points = _history.Range(d.MacAddress, fromUtc: now.AddMinutes(-2), takeLast: 20);
            var trend = TrendPredictor.FitConfirmed(points);
            if (trend is null) continue;

            var (lowLimit, highLimit) = Limits(d);
            var eta = lowLimit is not null ? TrendPredictor.SecondsUntilBelow(trend, lowLimit.Value) : null;
            var direction = "drop below";
            var limit = lowLimit;
            if (eta is null && highLimit is not null)
            {
                eta = TrendPredictor.SecondsUntilAbove(trend, highLimit.Value);
                direction = "rise above";
                limit = highLimit;
            }
            if (eta is null || eta > 180) continue;

            highlighted.Add(d.MacAddress);
            var score = 0.6 + 0.3 * (1 - eta.Value / 180);
            insightQueue.Enqueue(new Suggestion($"trend:{d.MacAddress}", "AutomatedInsight",
                $"{d.Name} predicted to {direction} {limit:0.#}{d.Unit}",
                $"Trending {trend.SlopePerSecond * 60:+0.0;-0.0}{d.Unit}/min over the last {trend.Points} readings - " +
                $"expected to cross in about {FormatAge(TimeSpan.FromSeconds(eta.Value))}.",
                "Trend forecast (least-squares regression)", score, AlertLevel.Warning, d.MacAddress, null, d.Name), -score);
        }

        return new InsightsResult(
            DrainTop(actionQueue, maxPerList, now),
            DrainTop(insightQueue, maxPerList, now),
            highlighted.ToList(),
            patterns,
            recent);
    }

    /// <summary>
    /// Loads three past episodes of the brief's example pattern ("Moisture Sensor B drops below 20%, operator
    /// searches Pump A and starts it") so the engine can be demonstrated without waiting for live repetitions.
    /// </summary>
    public string TrainSampleHistory()
    {
        var sensor = _registry.FindByNameOrMac("Moisture Sensor B")
                     ?? _registry.All().FirstOrDefault(d => d.Kind == DeviceKind.MoistureSensor);
        var pump = _registry.FindByNameOrMac("Pump A")
                   ?? _registry.All().FirstOrDefault(d => d.Kind == DeviceKind.WaterPump);
        if (sensor is null || pump is null)
            return "Register at least one moisture sensor and one water pump first (start the device simulator).";

        const int sampleEpisodes = 3;
        var cond = ConditionKey(sensor.MacAddress, FaultCode.CriticalMoisture);
        var find = new OperatorEvent(DateTime.UtcNow, OperatorEventKind.Search, $"find:{pump.MacAddress}",
            $"Search \"{pump.Name}\"", pump.MacAddress, null, IsSample: true);
        var start = new OperatorEvent(DateTime.UtcNow, OperatorEventKind.Command, $"cmd:{pump.MacAddress}:TurnOn",
            $"Start {pump.Name}", pump.MacAddress, "TurnOn", IsSample: true);

        lock (_lock)
        {
            _episodes[cond] = _episodes.GetValueOrDefault(cond) + sampleEpisodes;
            for (var i = 0; i < sampleEpisodes; i++)
            {
                Increment(_conditionToAction, cond, find.ActionKey);
                Increment(_conditionToAction, cond, start.ActionKey);
                Increment(_transitions, find.ActionKey, start.ActionKey);
            }
            _actionCatalog.TryAdd(find.ActionKey, find);
            _actionCatalog.TryAdd(start.ActionKey, start);
            _recentEvents.AddLast(start);
            _recentEvents.AddLast(find);
        }

        return $"Loaded {sampleEpisodes} sample episodes: \"{sensor.Name} below {_options.CurrentValue.CriticalMoisturePercent:0}%\" " +
               $"→ search \"{pump.Name}\" → start {pump.Name}.";
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    private Suggestion? BuildActionSuggestion(string id, OperatorEvent example, Dictionary<string, DeviceView> devices,
        string detail, string basis, double score, AlertLevel level)
    {
        if (example.Kind == OperatorEventKind.Command)
        {
            var title = example.DeviceMac is not null && devices.TryGetValue(example.DeviceMac, out var d)
                ? $"{CommandService.VerbFor(d.Kind, example.CommandAction != "TurnOff")} {d.Name}"
                : example.Label;
            if (example.CommandAction == "Toggle") title = example.Label;
            return new Suggestion(id, "SuggestedAction", title, detail, basis, score, level,
                example.DeviceMac, example.CommandAction, null);
        }

        // A learned search becomes "show me that device" - it pre-applies the filter the operator would have typed.
        var name = example.DeviceMac is not null && devices.TryGetValue(example.DeviceMac, out var dev)
            ? dev.Name
            : example.Label.Replace("Search ", "").Trim('"');
        return new Suggestion(id, "SuggestedAction", $"Check {name}", detail, basis, score * 0.95, level,
            example.DeviceMac, null, name);
    }

    /// <summary>Don't suggest "start Pump A" when Pump A is already running.</summary>
    private static bool IsAlreadySatisfied(OperatorEvent example, Dictionary<string, DeviceView> devices)
    {
        if (example.Kind != OperatorEventKind.Command || example.DeviceMac is null) return false;
        if (!devices.TryGetValue(example.DeviceMac, out var d)) return true; // device gone
        var current = d.DesiredState ?? d.ReportedState;
        return example.CommandAction switch
        {
            "TurnOn" => current == true,
            "TurnOff" => current == false,
            _ => false
        };
    }

    private (double? low, double? high) Limits(DeviceView d)
    {
        var o = _options.CurrentValue;
        return d.Kind switch
        {
            DeviceKind.MoistureSensor => (d.ExpectedMin ?? o.CriticalMoisturePercent, d.ExpectedMax),
            DeviceKind.SmartPlug => (null, d.ExpectedMax ?? o.CriticalPowerWatts),
            _ => (d.ExpectedMin, d.ExpectedMax)
        };
    }

    private List<Suggestion> DrainTop(PriorityQueue<Suggestion, double> queue, int max, DateTime now)
    {
        var result = new List<Suggestion>();
        var seenTitles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        lock (_lock)
        {
            while (result.Count < max && queue.TryDequeue(out var s, out _))
            {
                if (_dismissedUntil.TryGetValue(s.Id, out var until) && until > now) continue;
                // Two algorithms often reach the same conclusion; show it once, with the higher-scoring reason.
                if (!seenTitles.Add(s.Title)) continue;
                result.Add(s);
            }
        }
        return result;
    }

    private List<LearnedPattern> BuildPatternTable(Dictionary<string, DeviceView> devices)
    {
        var rows = new List<LearnedPattern>();
        foreach (var (cond, actions) in _conditionToAction)
        {
            var episodes = Math.Max(1, _episodes.GetValueOrDefault(cond));
            foreach (var (actionKey, count) in actions)
            {
                var label = _actionCatalog.TryGetValue(actionKey, out var ex) ? ex.Label : actionKey;
                rows.Add(new LearnedPattern(ConditionLabel(cond, devices), label, count, episodes,
                    Math.Min(1.0, (double)count / episodes)));
            }
        }
        return rows.OrderByDescending(r => r.Count).ThenByDescending(r => r.Confidence).Take(12).ToList();
    }

    private string ConditionLabel(string cond, Dictionary<string, DeviceView> devices)
    {
        var split = cond.LastIndexOf(':');
        var mac = cond[..split];
        var code = Enum.Parse<FaultCode>(cond[(split + 1)..]);
        var name = devices.TryGetValue(mac, out var d) ? d.Name : mac;
        return code switch
        {
            FaultCode.CriticalMoisture => $"{name} below {_options.CurrentValue.CriticalMoisturePercent:0}%",
            FaultCode.PowerSpike => $"{name} power spike",
            FaultCode.Disconnected => $"{name} disconnected",
            _ => $"{name} out of range"
        };
    }

    private static void Increment(Dictionary<string, Dictionary<string, int>> table, string from, string to)
    {
        if (!table.TryGetValue(from, out var row))
        {
            row = new Dictionary<string, int>();
            table[from] = row;
        }
        row[to] = row.GetValueOrDefault(to) + 1;
    }

    private static string FormatAge(TimeSpan t) =>
        t.TotalSeconds < 90 ? $"{t.TotalSeconds:0}s" : t.TotalMinutes < 90 ? $"{t.TotalMinutes:0} min" : $"{t.TotalHours:0.#} h";
}
