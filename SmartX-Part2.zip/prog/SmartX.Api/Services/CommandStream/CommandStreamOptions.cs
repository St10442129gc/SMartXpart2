namespace SmartX.Api.Services.CommandStream;

/// <summary>Bound from the "CommandStream" section of appsettings.json.</summary>
public class CommandStreamOptions
{
    public const string SectionName = "CommandStream";

    /// <summary>
    /// Simulated processing cost of one standard-lane packet. A real gateway spends this time on
    /// validation, persistence and fan-out; here it lets a visible backlog build up so you can
    /// watch critical packets overtake it. Priority-lane packets never pay this delay.
    /// </summary>
    public int StandardLaneDelayMs { get; set; } = 60;

    /// <summary>A device that has not reported for this long is marked disconnected by the watchdog.</summary>
    public int HeartbeatTimeoutSeconds { get; set; } = 15;

    /// <summary>Smart plug readings above this draw are triaged as a critical power spike.</summary>
    public double CriticalPowerWatts { get; set; } = 2500;

    /// <summary>Moisture readings below this percentage are triaged as a critical moisture drop.</summary>
    public double CriticalMoisturePercent { get; set; } = 20;

    /// <summary>Maximum number of timestamped readings kept per device in the SortedDictionary history.</summary>
    public int HistoryCapacityPerDevice { get; set; } = 600;

    /// <summary>Hard cap on the standard FIFO queue so a flood cannot exhaust gateway memory.</summary>
    public int StandardQueueCapacity { get; set; } = 10_000;
}
