using Microsoft.Extensions.Options;

namespace SmartX.Api.Services.CommandStream;

// =====================================================================
// ASSIGNMENT REQUIREMENT (PART 2): SORTED DICTIONARY
// Each device's historical log is a SortedDictionary<DateTime, double>
// keyed by the timestamp the DEVICE stamped on the reading.
//
// Why sorted and not just a List we append to? Because packets are NOT
// processed in the order they were taken: a critical reading jumps the
// queue through the priority lane, and devices on a flaky mesh link
// deliver late. A SortedDictionary keeps every insert in timestamp
// order automatically (O(log n) per insert), so the dashboard can walk
// the keys and draw a correct timeline graph with no sorting step.
// =====================================================================
public class TelemetryHistory
{
    private readonly Dictionary<string, SortedDictionary<DateTime, double>> _byDevice = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _lock = new();
    private readonly IOptionsMonitor<CommandStreamOptions> _options;

    public TelemetryHistory(IOptionsMonitor<CommandStreamOptions> options) => _options = options;

    public record HistoryPoint(DateTime TimestampUtc, double Value);

    public void Append(string mac, DateTime timestampUtc, double value)
    {
        lock (_lock)
        {
            if (!_byDevice.TryGetValue(mac, out var log))
            {
                log = new SortedDictionary<DateTime, double>();
                _byDevice[mac] = log;
            }

            // Two readings stamped with the identical tick would collide on the key; nudge forward by one
            // tick (100ns) so neither is lost and order is still preserved.
            var key = timestampUtc;
            while (log.ContainsKey(key)) key = key.AddTicks(1);
            log[key] = value;

            // Bounded history: the smallest key is always the oldest reading, so evicting it is trivial.
            var capacity = _options.CurrentValue.HistoryCapacityPerDevice;
            while (log.Count > capacity)
                log.Remove(log.Keys.First());
        }
    }

    /// <summary>Readings for one device, oldest first, optionally limited to a time window.</summary>
    public List<HistoryPoint> Range(string mac, DateTime? fromUtc = null, DateTime? toUtc = null, int? takeLast = null)
    {
        lock (_lock)
        {
            if (!_byDevice.TryGetValue(mac, out var log)) return new();

            // Keys are already in chronological order - just walk them.
            IEnumerable<KeyValuePair<DateTime, double>> query = log;
            if (fromUtc is not null) query = query.SkipWhile(kv => kv.Key < fromUtc.Value);
            if (toUtc is not null) query = query.TakeWhile(kv => kv.Key <= toUtc.Value);

            var points = query.Select(kv => new HistoryPoint(kv.Key, kv.Value)).ToList();
            if (takeLast is > 0 && points.Count > takeLast)
                points = points.GetRange(points.Count - takeLast.Value, takeLast.Value);
            return points;
        }
    }

    public int Count(string mac)
    {
        lock (_lock) return _byDevice.TryGetValue(mac, out var log) ? log.Count : 0;
    }
}
