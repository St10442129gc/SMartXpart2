using Microsoft.Extensions.Options;
using SmartX.Api.Models;
using SmartX.Api.Services.Insights;

namespace SmartX.Api.Services.CommandStream;

/// <summary>
/// The gateway's processing engine. Runs in the background for the lifetime of the API and:
///  1. takes the next packet - priority lane first, then the FIFO lane,
///  2. finds its device with an O(1) Dictionary lookup and updates its live state,
///  3. files the reading into the SortedDictionary history,
///  4. raises / clears faults in the HashSet tracker and tells the insights engine about new ones,
///  5. keeps the Part 1 health score and live feed in step,
///  6. sweeps for devices that have stopped sending heartbeats.
/// </summary>
public class StreamProcessor : BackgroundService
{
    private const int MaxLogEntries = 60;

    private readonly TelemetryIngestionQueue _queue;
    private readonly DeviceRegistry _registry;
    private readonly TelemetryHistory _history;
    private readonly FaultTracker _faults;
    private readonly ActionInsightsEngine _insights;
    private readonly TelemetryStore _part1Store;
    private readonly HealthScoreService _health;
    private readonly IOptionsMonitor<CommandStreamOptions> _options;
    private readonly ILogger<StreamProcessor> _logger;

    private readonly LinkedList<ProcessedRecord> _log = new();
    private readonly object _logLock = new();

    private long _processedStandard;
    private long _processedPriority;
    private volatile bool _paused;
    private int? _delayOverrideMs;

    public StreamProcessor(TelemetryIngestionQueue queue, DeviceRegistry registry, TelemetryHistory history,
        FaultTracker faults, ActionInsightsEngine insights, TelemetryStore part1Store, HealthScoreService health,
        IOptionsMonitor<CommandStreamOptions> options, ILogger<StreamProcessor> logger)
    {
        _queue = queue;
        _registry = registry;
        _history = history;
        _faults = faults;
        _insights = insights;
        _part1Store = part1Store;
        _health = health;
        _options = options;
        _logger = logger;
    }

    public bool Paused => _paused;
    public int StandardLaneDelayMs => _delayOverrideMs ?? _options.CurrentValue.StandardLaneDelayMs;

    /// <summary>Pausing lets a backlog build up, so on resume you can watch critical packets come out first.</summary>
    public void SetPaused(bool paused) => _paused = paused;

    public void SetStandardLaneDelay(int ms) => _delayOverrideMs = Math.Clamp(ms, 0, 2000);

    public ProcessorStats Stats() => new(_paused, StandardLaneDelayMs,
        Interlocked.Read(ref _processedStandard), Interlocked.Read(ref _processedPriority));

    public record ProcessorStats(bool Paused, int StandardLaneDelayMs, long ProcessedStandard, long ProcessedPriority);

    public List<ProcessedRecord> RecentlyProcessed(int take = 25)
    {
        lock (_logLock) return _log.Take(take).ToList();
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var lastSweep = DateTime.UtcNow;

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                if (DateTime.UtcNow - lastSweep > TimeSpan.FromSeconds(1))
                {
                    SweepHeartbeats();
                    lastSweep = DateTime.UtcNow;
                }

                if (_paused)
                {
                    await Task.Delay(100, stoppingToken);
                    continue;
                }

                if (_queue.TryDequeueNext(out var packet))
                {
                    Process(packet);

                    // Emulates the work an ordinary packet costs on a constrained gateway. Critical packets skip it.
                    if (packet.Lane == ProcessingLane.Standard && StandardLaneDelayMs > 0)
                        await Task.Delay(StandardLaneDelayMs, stoppingToken);
                }
                else
                {
                    await _queue.WaitForWorkAsync(TimeSpan.FromMilliseconds(500), stoppingToken);
                }
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                // One bad packet must never take the whole processing loop (and the API) down with it.
                _logger.LogError(ex, "Failed to process a telemetry packet");
            }
        }
    }

    private void Process(QueuedPacket p)
    {
        var now = DateTime.UtcNow;
        string name = p.MacAddress, unit = p.Unit;
        string? profileId = null;
        double? min = null, max = null;
        var kind = DeviceKind.TemperatureSensor;

        var isLatest = true;

        // A packet the device sent BEFORE it was declared offline (it sat in the backlog) is not proof the
        // device is back, so it must not flip the node online again.
        var offlineSince = _faults.DisconnectedSince(p.MacAddress);
        var sentBeforeDisconnect = offlineSince is not null && p.DeviceTimestampUtc <= offlineSince;

        // O(1) Dictionary lookup + update of the device's live state.
        var known = _registry.TryUpdate(p.MacAddress, d =>
        {
            d.PacketsProcessed++;
            name = d.Name; unit = d.Unit; profileId = d.SensorProfileId;
            min = d.ExpectedMin; max = d.ExpectedMax; kind = d.Kind;

            // A critical packet that jumped the queue is NEWER than ordinary packets still waiting behind it.
            // When those older packets are processed afterwards they must not overwrite the live value, so the
            // device's current state only moves forward in DEVICE time, never in processing order.
            if (sentBeforeDisconnect || (d.LatestReadingUtc is not null && p.DeviceTimestampUtc < d.LatestReadingUtc))
            {
                isLatest = false;
                return;
            }
            d.LastSeenUtc = now;
            d.IsOnline = true;
            d.LatestReadingUtc = p.DeviceTimestampUtc;
            d.LastValue = p.Value;
            if (p.SwitchState is bool reported) d.ReportedState = reported;
        });
        if (!known) return; // device was removed while the packet waited

        if (isLatest) _faults.MarkReconnected(p.MacAddress);

        // Late or not, every reading lands in its correct place on the timeline - the SortedDictionary sorts it in.
        _history.Append(p.MacAddress, p.DeviceTimestampUtc, p.Value);

        if (!isLatest)
        {
            Count(p.Lane);
            AddToLog(new ProcessedRecord(p.Sequence, p.MacAddress, name, p.Value, unit, p.Lane, p.Severity,
                "Older than the current reading - archived to history only", (now - p.EnqueuedUtc).TotalMilliseconds, now,
                ArchivedOnly: true));
            return;
        }

        // ---- Fault evaluation ----
        var level = AlertLevel.None;
        string? message = null;

        var criticalCode = kind == DeviceKind.SmartPlug ? FaultCode.PowerSpike : FaultCode.CriticalMoisture;
        if (p.Severity == AlertLevel.Critical)
        {
            level = AlertLevel.Critical;
            message = p.TriageReason;
            if (_faults.Raise(p.MacAddress, criticalCode, p.TriageReason ?? "Critical reading"))
                _insights.OnConditionStarted(p.MacAddress, criticalCode, now);
        }
        else
        {
            _faults.Clear(p.MacAddress, criticalCode);
        }

        var outOfRange = (min is not null && p.Value < min) || (max is not null && p.Value > max);
        if (outOfRange && level != AlertLevel.Critical)
        {
            level = AlertLevel.Warning;
            message = $"{p.Value:0.##}{unit} is outside the expected {min?.ToString("0.#") ?? "-∞"}–{max?.ToString("0.#") ?? "∞"}{unit} band";
            if (_faults.Raise(p.MacAddress, FaultCode.OutOfRange, message))
                _insights.OnConditionStarted(p.MacAddress, FaultCode.OutOfRange, now);
        }
        else if (!outOfRange)
        {
            _faults.Clear(p.MacAddress, FaultCode.OutOfRange);
        }

        _registry.TryUpdate(p.MacAddress, d =>
        {
            d.AlertLevel = level;
            d.AlertMessage = message;
        });

        // ---- Keep Part 1 (health score + live feed) in step ----
        if (!p.FromLegacyEndpoint && profileId is not null && _part1Store.Sensors.TryGetValue(profileId, out var profile))
        {
            var anomalous = level != AlertLevel.None;
            lock (profile)
            {
                if (anomalous) _health.RecordAnomaly(profile);
                else _health.RecordCleanReading(profile);
            }
            _part1Store.PushLive(new TelemetryEnvelope<double>(new TelemetryPacket<double>
            {
                DeviceId = name,
                Value = p.Value,
                Unit = unit,
                TimestampUtc = p.DeviceTimestampUtc,
                IsAnomalous = anomalous
            }));
        }

        Count(p.Lane);
        AddToLog(new ProcessedRecord(p.Sequence, p.MacAddress, name, p.Value, unit, p.Lane, level,
            p.TriageReason ?? message, (now - p.EnqueuedUtc).TotalMilliseconds, now));
    }

    private void Count(ProcessingLane lane)
    {
        if (lane == ProcessingLane.Priority) Interlocked.Increment(ref _processedPriority);
        else Interlocked.Increment(ref _processedStandard);
    }

    private void AddToLog(ProcessedRecord record)
    {
        lock (_logLock)
        {
            _log.AddFirst(record);
            while (_log.Count > MaxLogEntries) _log.RemoveLast();
        }
    }

    /// <summary>
    /// Handles a disconnect report from any source (the device itself, the Part 1 button, or the watchdog).
    /// Returns false when the node was already known to be offline - the HashSet suppresses the duplicate.
    /// </summary>
    public bool HandleDisconnect(string mac, string reason)
    {
        mac = DeviceRegistry.NormaliseMac(mac);
        if (!_registry.Contains(mac)) return false;
        if (!_faults.ReportDisconnect(mac, reason)) return false;

        _registry.TryUpdate(mac, d =>
        {
            d.IsOnline = false;
            d.AlertLevel = AlertLevel.Critical;
            d.AlertMessage = reason;
        });
        _insights.OnConditionStarted(mac, FaultCode.Disconnected, DateTime.UtcNow);
        return true;
    }

    private void SweepHeartbeats()
    {
        var timeout = TimeSpan.FromSeconds(_options.CurrentValue.HeartbeatTimeoutSeconds);
        var cutoff = DateTime.UtcNow - timeout;
        foreach (var d in _registry.All())
        {
            if (d.IsOnline && d.LastSeenUtc is not null && d.LastSeenUtc < cutoff)
                HandleDisconnect(d.MacAddress, $"No heartbeat for {timeout.TotalSeconds:0}s");
        }
    }
}
