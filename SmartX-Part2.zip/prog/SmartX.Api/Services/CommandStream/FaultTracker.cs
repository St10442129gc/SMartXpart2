using SmartX.Api.Models;

namespace SmartX.Api.Services.CommandStream;

/// <summary>A unique fault: the same code on the same device is the same fault, no matter how often it is reported.</summary>
public readonly record struct FaultKey(string MacAddress, FaultCode Code);

public record ActiveFault(string MacAddress, FaultCode Code, DateTime SinceUtc, string Message);

// =====================================================================
// ASSIGNMENT REQUIREMENT (PART 2): HASHSET<T>
//
//  * _disconnected - HashSet<string> of MAC addresses that are offline.
//  * _activeFaults - HashSet<FaultKey> of unique (device, fault) pairs.
//
// HashSet.Add() returns false when the element is already present. That
// single O(1) check is what stops a node that keeps shouting "I've lost
// my link" (or a watchdog that fires on every sweep) from generating a
// flood of duplicate disconnect alerts: only the FIRST report raises an
// alert, every repeat is counted as suppressed and otherwise ignored.
// FaultKey is a record struct, so two keys with the same MAC and code
// are equal and hash identically - exactly the uniqueness we need.
// =====================================================================
public class FaultTracker
{
    private readonly HashSet<string> _disconnected = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<FaultKey> _activeFaults = new();

    // Side table so the dashboard and insights engine know when each fault started and why.
    private readonly Dictionary<FaultKey, ActiveFault> _details = new();
    private readonly object _lock = new();

    private long _suppressedDisconnects;
    private long _totalRaised;

    /// <summary>Returns true only the first time a device is reported disconnected. Repeats are suppressed.</summary>
    public bool ReportDisconnect(string mac, string reason)
    {
        lock (_lock)
        {
            if (!_disconnected.Add(mac)) // O(1) - already known to be offline
            {
                _suppressedDisconnects++;
                return false;
            }
            RaiseInternal(new FaultKey(mac, FaultCode.Disconnected), reason);
            return true;
        }
    }

    /// <summary>Device spoke again: clear its disconnected state. Returns true if it had been offline.</summary>
    public bool MarkReconnected(string mac)
    {
        lock (_lock)
        {
            if (!_disconnected.Remove(mac)) return false;
            ClearInternal(new FaultKey(mac, FaultCode.Disconnected));
            return true;
        }
    }

    /// <summary>When the device was declared offline, or null if it is online.</summary>
    public DateTime? DisconnectedSince(string mac)
    {
        lock (_lock)
            return _details.TryGetValue(new FaultKey(mac, FaultCode.Disconnected), out var f) ? f.SinceUtc : null;
    }

    public bool IsDisconnected(string mac)
    {
        lock (_lock) return _disconnected.Contains(mac); // O(1)
    }

    /// <summary>Raises a fault if it is not already active. Returns true when it is a NEW fault.</summary>
    public bool Raise(string mac, FaultCode code, string message)
    {
        lock (_lock)
        {
            var key = new FaultKey(mac, code);
            // Still active from an earlier reading: nothing new to alert on.
            if (_activeFaults.Contains(key)) return false;
            RaiseInternal(key, message);
            return true;
        }
    }

    /// <summary>Clears a fault. Returns true if it had been active.</summary>
    public bool Clear(string mac, FaultCode code)
    {
        lock (_lock) return ClearInternal(new FaultKey(mac, code));
    }

    public List<ActiveFault> ActiveFaults()
    {
        lock (_lock) return _details.Values.OrderByDescending(f => f.SinceUtc).ToList();
    }

    public List<string> DisconnectedNodes()
    {
        lock (_lock) return _disconnected.ToList();
    }

    public HashSet<string> MacsWithFaults()
    {
        lock (_lock) return _activeFaults.Select(f => f.MacAddress).ToHashSet(StringComparer.OrdinalIgnoreCase);
    }

    public FaultStats Stats()
    {
        lock (_lock) return new FaultStats(_activeFaults.Count, _disconnected.Count, _suppressedDisconnects, _totalRaised);
    }

    public record FaultStats(int ActiveFaults, int DisconnectedNodes, long SuppressedDuplicateDisconnects, long TotalRaised);

    private void RaiseInternal(FaultKey key, string message)
    {
        _activeFaults.Add(key);
        _details[key] = new ActiveFault(key.MacAddress, key.Code, DateTime.UtcNow, message);
        _totalRaised++;
    }

    private bool ClearInternal(FaultKey key)
    {
        _details.Remove(key);
        return _activeFaults.Remove(key);
    }
}
