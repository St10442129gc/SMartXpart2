using SmartX.Api.Models;

namespace SmartX.Api.Services.CommandStream;

// =====================================================================
// ASSIGNMENT REQUIREMENT (PART 2): DICTIONARY<TKey, TValue>
// Every live, registered device is stored in a Dictionary keyed by its
// MAC address. When a telemetry packet arrives the processor finds the
// device with one O(1) hash lookup, instead of scanning a list of every
// device on the mesh (O(n)) for each of the thousands of packets a
// second a busy gateway handles.
// =====================================================================
public class DeviceRegistry
{
    private readonly Dictionary<string, LiveDevice> _devices = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _lock = new();
    private readonly TelemetryStore _part1Store;

    public DeviceRegistry(TelemetryStore part1Store) => _part1Store = part1Store;

    /// <summary>MAC addresses are case-insensitive and sometimes arrive with '-' separators; store one canonical form.</summary>
    public static string NormaliseMac(string mac) => mac.Trim().Replace('-', ':').ToUpperInvariant();

    public int Count
    {
        get { lock (_lock) return _devices.Count; }
    }

    /// <summary>Adds the device, or updates its descriptive fields if that MAC is already registered.</summary>
    public DeviceView Register(RegisterDeviceRequest request, string? sensorProfileId = null)
    {
        var mac = NormaliseMac(request.MacAddress);
        lock (_lock)
        {
            if (!_devices.TryGetValue(mac, out var device))
            {
                device = new LiveDevice
                {
                    MacAddress = mac,
                    Kind = request.Kind,
                    // Actuators start switched off until they report otherwise.
                    ReportedState = request.Kind.IsActuator() ? false : null
                };
                _devices[mac] = device; // O(1) insert
            }

            device.Name = string.IsNullOrWhiteSpace(request.Name) ? mac : request.Name.Trim();
            device.Location = request.Location;
            device.Unit = request.Kind.DefaultUnit();
            device.ExpectedMin = request.ExpectedMin;
            device.ExpectedMax = request.ExpectedMax;
            if (sensorProfileId is not null) device.SensorProfileId = sensorProfileId;

            return device.ToView(HealthScoreFor(device));
        }
    }

    /// <summary>O(1) existence check used while triaging incoming packets.</summary>
    public bool Contains(string mac)
    {
        lock (_lock) return _devices.ContainsKey(NormaliseMac(mac));
    }

    /// <summary>O(1) snapshot lookup by MAC address.</summary>
    public DeviceView? Find(string mac)
    {
        lock (_lock)
            return _devices.TryGetValue(NormaliseMac(mac), out var d) ? d.ToView(HealthScoreFor(d)) : null;
    }

    /// <summary>
    /// Runs <paramref name="mutate"/> against the live device under the registry lock. This is the only way
    /// anything outside the registry changes device state, so readers never see a half-updated device.
    /// </summary>
    public bool TryUpdate(string mac, Action<LiveDevice> mutate)
    {
        lock (_lock)
        {
            if (!_devices.TryGetValue(NormaliseMac(mac), out var device)) return false; // O(1)
            mutate(device);
            return true;
        }
    }

    /// <summary>Reads a value from the live device under the lock without exposing the mutable object.</summary>
    public T? Read<T>(string mac, Func<LiveDevice, T> selector)
    {
        lock (_lock)
            return _devices.TryGetValue(NormaliseMac(mac), out var d) ? selector(d) : default;
    }

    public List<DeviceView> All()
    {
        lock (_lock)
            return _devices.Values.Select(d => d.ToView(HealthScoreFor(d))).ToList();
    }

    /// <summary>Resolves a free-text name such as "Pump A" to a device, used by the search-pattern analyser.</summary>
    public DeviceView? FindByNameOrMac(string term)
    {
        var t = term.Trim();
        lock (_lock)
        {
            if (_devices.TryGetValue(NormaliseMac(t), out var byMac)) return byMac.ToView(HealthScoreFor(byMac));
            var byName = _devices.Values.FirstOrDefault(d => string.Equals(d.Name, t, StringComparison.OrdinalIgnoreCase))
                         ?? _devices.Values.FirstOrDefault(d => d.Name.Contains(t, StringComparison.OrdinalIgnoreCase));
            return byName?.ToView(HealthScoreFor(byName));
        }
    }

    public List<string> MacsOfKind(DeviceKind kind)
    {
        lock (_lock)
            return _devices.Values.Where(d => d.Kind == kind).Select(d => d.MacAddress).ToList();
    }

    private int? HealthScoreFor(LiveDevice device) =>
        device.SensorProfileId is not null && _part1Store.Sensors.TryGetValue(device.SensorProfileId, out var profile)
            ? profile.HealthScore
            : null;
}
