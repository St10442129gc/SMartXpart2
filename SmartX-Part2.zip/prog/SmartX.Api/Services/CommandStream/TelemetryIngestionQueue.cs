using Microsoft.Extensions.Options;
using SmartX.Api.Models;

namespace SmartX.Api.Services.CommandStream;

// =====================================================================
// ASSIGNMENT REQUIREMENT (PART 2): QUEUE<T> and PRIORITY QUEUE
//
// Every telemetry packet that hits the API is triaged on arrival and
// placed in one of two lanes:
//
//  * _standardLane - a Queue<QueuedPacket>. Ordinary readings are
//    processed strictly First-In-First-Out, so a sensor's readings are
//    handled in the order they arrived.
//
//  * _priorityLane - a PriorityQueue<QueuedPacket, (int, long)>. Severe
//    power spikes and critical moisture drops go here. The processor
//    always drains this lane before taking anything from the standard
//    queue, so a critical alert bypasses however long the standard
//    backlog is. The priority is (severity rank, arrival sequence): the
//    most severe alert wins, and alerts of equal severity stay FIFO.
// =====================================================================
public class TelemetryIngestionQueue
{
    private readonly Queue<QueuedPacket> _standardLane = new();
    private readonly PriorityQueue<QueuedPacket, (int SeverityRank, long Sequence)> _priorityLane = new();
    private readonly object _lock = new();
    private readonly SemaphoreSlim _signal = new(0);

    private readonly DeviceRegistry _registry;
    private readonly IOptionsMonitor<CommandStreamOptions> _options;

    private long _sequence;
    private long _droppedStandard;
    private long _totalEnqueuedStandard;
    private long _totalEnqueuedPriority;

    public TelemetryIngestionQueue(DeviceRegistry registry, IOptionsMonitor<CommandStreamOptions> options)
    {
        _registry = registry;
        _options = options;
    }

    public record EnqueueResult(long Sequence, ProcessingLane Lane, AlertLevel Severity, string? Reason, int PositionInLane);

    /// <summary>Triages a packet and drops it into the correct lane. Returns null if the device is not registered.</summary>
    public EnqueueResult? Enqueue(DeviceTelemetryRequest request, bool fromLegacyEndpoint = false)
    {
        var mac = DeviceRegistry.NormaliseMac(request.MacAddress);
        var kind = _registry.Read(mac, d => (DeviceKind?)d.Kind);
        if (kind is null) return null;

        var (severity, reason) = Triage(kind.Value, request.Value);

        lock (_lock)
        {
            var packet = new QueuedPacket
            {
                Sequence = ++_sequence,
                MacAddress = mac,
                Value = request.Value,
                Unit = request.Unit ?? kind.Value.DefaultUnit(),
                SwitchState = request.SwitchState,
                DeviceTimestampUtc = request.TimestampUtc?.ToUniversalTime() ?? DateTime.UtcNow,
                Severity = severity,
                TriageReason = reason,
                FromLegacyEndpoint = fromLegacyEndpoint
            };

            int position;
            if (severity == AlertLevel.Critical)
            {
                packet.Lane = ProcessingLane.Priority;
                // Lower tuple sorts first: Critical (2) -> rank 0, then earliest sequence.
                _priorityLane.Enqueue(packet, (2 - (int)severity, packet.Sequence));
                _totalEnqueuedPriority++;
                position = _priorityLane.Count;
            }
            else
            {
                packet.Lane = ProcessingLane.Standard;
                _standardLane.Enqueue(packet);
                _totalEnqueuedStandard++;

                // Bounded: under a flood, shed the oldest ordinary reading rather than run out of memory.
                // Critical packets are never shed.
                while (_standardLane.Count > _options.CurrentValue.StandardQueueCapacity)
                {
                    _standardLane.Dequeue();
                    _droppedStandard++;
                }
                position = _standardLane.Count;
            }

            _signal.Release();
            return new EnqueueResult(packet.Sequence, packet.Lane, severity, reason, position);
        }
    }

    /// <summary>
    /// Takes the next packet to process. The priority lane is ALWAYS checked first, which is what lets
    /// a critical alert jump ahead of every ordinary packet already waiting in the FIFO queue.
    /// </summary>
    public bool TryDequeueNext(out QueuedPacket packet)
    {
        lock (_lock)
        {
            if (_priorityLane.TryDequeue(out packet!, out _)) return true;
            if (_standardLane.TryDequeue(out packet!)) return true;
            return false;
        }
    }

    /// <summary>Waits until something is enqueued (or the timeout passes) so the processor does not busy-spin.</summary>
    public Task WaitForWorkAsync(TimeSpan timeout, CancellationToken ct) => _signal.WaitAsync(timeout, ct);

    public QueueStats Stats()
    {
        lock (_lock)
        {
            return new QueueStats(
                _standardLane.Count, _priorityLane.Count,
                _totalEnqueuedStandard, _totalEnqueuedPriority, _droppedStandard,
                _priorityLane.TryPeek(out var next, out _) ? next.MacAddress : null);
        }
    }

    public record QueueStats(int StandardDepth, int PriorityDepth, long TotalStandard, long TotalPriority,
        long DroppedStandard, string? NextPriorityMac);

    /// <summary>Decides whether a reading is critical enough to bypass the FIFO queue.</summary>
    private (AlertLevel severity, string? reason) Triage(DeviceKind kind, double value)
    {
        var o = _options.CurrentValue;
        return kind switch
        {
            DeviceKind.SmartPlug when value >= o.CriticalPowerWatts =>
                (AlertLevel.Critical, $"Severe power spike: {value:0} W (limit {o.CriticalPowerWatts:0} W)"),
            DeviceKind.MoistureSensor when value < o.CriticalMoisturePercent =>
                (AlertLevel.Critical, $"Critical moisture drop: {value:0.#}% (below {o.CriticalMoisturePercent:0}%)"),
            _ => (AlertLevel.None, null)
        };
    }
}
