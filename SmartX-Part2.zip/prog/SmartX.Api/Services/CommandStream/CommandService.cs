using SmartX.Api.Models;

namespace SmartX.Api.Services.CommandStream;

public record StateChange(string MacAddress, string DeviceName, bool? PreviousState, bool NewState);

/// <summary>One manual override as the operator issued it. A group command ("shut down all valves") holds one change per device.</summary>
public class CommandRecord
{
    public Guid Id { get; init; } = Guid.NewGuid();
    public string Action { get; init; } = string.Empty;
    public string Label { get; init; } = string.Empty;
    public string? TargetMac { get; init; }
    public List<StateChange> Changes { get; init; } = new();
    public DateTime IssuedUtc { get; init; } = DateTime.UtcNow;
    public string Source { get; init; } = "Manual";
}

/// <summary>What a device receives when it polls for work.</summary>
public record DeviceCommandMessage(Guid CommandId, string MacAddress, bool TargetState, string Action, DateTime IssuedUtc);

public record CommandAuditEntry(DateTime Utc, string Kind, string Label, string Source, int DevicesAffected);

public record CommandResult(bool Ok, string Message, CommandRecord? Command);

// =====================================================================
// ASSIGNMENT REQUIREMENT (PART 2): STACK<T> - command history with UNDO
// Every manual override is pushed onto _undoStack together with the
// state each affected device was in BEFORE the command. Undo pops the
// most recent command (Last-In-First-Out) and sends every device back
// to its previous state - so a mistaken "shut down all valves" is
// reverted in one click, exactly as it was before.
//
// Commands reach the device through a per-device Queue<T> outbox: the
// device polls the API and receives its commands in the order they
// were issued, the same way real ESP32 firmware would.
// =====================================================================
public class CommandService
{
    private const int MaxUndoDepth = 100;
    private const int MaxAuditEntries = 200;

    private Stack<CommandRecord> _undoStack = new();
    private readonly Dictionary<string, Queue<DeviceCommandMessage>> _outbox = new(StringComparer.OrdinalIgnoreCase);
    private readonly LinkedList<CommandAuditEntry> _audit = new();
    private readonly object _lock = new();

    private readonly DeviceRegistry _registry;

    public CommandService(DeviceRegistry registry) => _registry = registry;

    public static readonly string[] SupportedActions =
        { "TurnOn", "TurnOff", "Toggle", "ShutdownAllValves", "OpenAllValves", "StopAllPumps" };

    public CommandResult Issue(IssueCommandRequest request)
    {
        var action = SupportedActions.FirstOrDefault(a => a.Equals(request.Action, StringComparison.OrdinalIgnoreCase));
        if (action is null)
            return new(false, $"Unknown action '{request.Action}'. Supported: {string.Join(", ", SupportedActions)}.", null);

        // Work out which devices change, and to what.
        List<(string mac, Func<bool?, bool> target)> targets;
        string label;

        switch (action)
        {
            case "ShutdownAllValves":
                targets = _registry.MacsOfKind(DeviceKind.Valve).Select(m => (m, (Func<bool?, bool>)(_ => false))).ToList();
                label = "Shut down all valves";
                break;
            case "OpenAllValves":
                targets = _registry.MacsOfKind(DeviceKind.Valve).Select(m => (m, (Func<bool?, bool>)(_ => true))).ToList();
                label = "Open all valves";
                break;
            case "StopAllPumps":
                targets = _registry.MacsOfKind(DeviceKind.WaterPump).Select(m => (m, (Func<bool?, bool>)(_ => false))).ToList();
                label = "Stop all pumps";
                break;
            default:
                if (string.IsNullOrWhiteSpace(request.MacAddress))
                    return new(false, $"'{action}' needs a MacAddress.", null);

                var device = _registry.Find(request.MacAddress);
                if (device is null) return new(false, $"Unknown device '{request.MacAddress}'.", null);
                if (!device.IsActuator) return new(false, $"{device.Name} is a {device.Kind} and cannot be switched.", null);

                Func<bool?, bool> target = action switch
                {
                    "TurnOn" => _ => true,
                    "TurnOff" => _ => false,
                    _ => current => !(current ?? false) // Toggle
                };
                targets = new() { (device.MacAddress, target) };
                var current = device.DesiredState ?? device.ReportedState;
                label = $"{VerbFor(device.Kind, target(current))} {device.Name}";
                break;
        }

        if (targets.Count == 0)
            return new(false, "No matching devices are registered for that command.", null);

        lock (_lock)
        {
            var changes = new List<StateChange>();
            foreach (var (mac, target) in targets)
            {
                StateChange? change = null;
                _registry.TryUpdate(mac, d =>
                {
                    // "Previous" is what the operator believed the state to be when they pressed the button.
                    var previous = d.DesiredState ?? d.ReportedState;
                    var next = target(previous);
                    d.DesiredState = next;
                    change = new StateChange(d.MacAddress, d.Name, previous, next);
                });
                if (change is null) continue;
                changes.Add(change);
            }

            var record = new CommandRecord
            {
                Action = action,
                Label = label,
                TargetMac = request.MacAddress is null ? null : DeviceRegistry.NormaliseMac(request.MacAddress),
                Changes = changes,
                Source = string.IsNullOrWhiteSpace(request.Source) ? "Manual" : request.Source!
            };

            foreach (var c in changes) SendToDevice(record.Id, c.MacAddress, c.NewState, action);

            _undoStack.Push(record); // LIFO: the newest command is always on top
            TrimUndoStack();
            Audit("Issued", label, record.Source, changes.Count);

            return new(true, $"{label} - sent to {changes.Count} device(s).", record);
        }
    }

    /// <summary>Pops the most recent command and restores every device it touched to its prior state.</summary>
    public CommandResult Undo()
    {
        lock (_lock)
        {
            if (!_undoStack.TryPop(out var last))
                return new(false, "Nothing to undo.", null);

            foreach (var change in last.Changes)
            {
                var restoreTo = change.PreviousState ?? false;
                _registry.TryUpdate(change.MacAddress, d => d.DesiredState = restoreTo);
                SendToDevice(last.Id, change.MacAddress, restoreTo, $"Undo:{last.Action}");
            }

            Audit("Undo", $"Reverted \"{last.Label}\"", "Operator", last.Changes.Count);
            return new(true, $"Reverted \"{last.Label}\" on {last.Changes.Count} device(s).", last);
        }
    }

    /// <summary>Called by a device when it polls. Drains its outbox in FIFO order.</summary>
    public List<DeviceCommandMessage> CollectPending(string mac)
    {
        lock (_lock)
        {
            var result = new List<DeviceCommandMessage>();
            if (_outbox.TryGetValue(DeviceRegistry.NormaliseMac(mac), out var queue))
                while (queue.TryDequeue(out var msg)) result.Add(msg);
            return result;
        }
    }

    /// <summary>Peek at the command Undo would revert, without removing it.</summary>
    public CommandRecord? PeekUndo()
    {
        lock (_lock) return _undoStack.TryPeek(out var top) ? top : null;
    }

    /// <summary>The undo stack, top (newest) first - Stack&lt;T&gt; enumerates in pop order.</summary>
    public List<CommandRecord> UndoStack()
    {
        lock (_lock) return _undoStack.ToList();
    }

    public int UndoDepth
    {
        get { lock (_lock) return _undoStack.Count; }
    }

    public List<CommandAuditEntry> AuditLog(int take = 30)
    {
        lock (_lock) return _audit.Take(take).ToList();
    }

    private void SendToDevice(Guid commandId, string mac, bool targetState, string action)
    {
        if (!_outbox.TryGetValue(mac, out var queue))
        {
            queue = new Queue<DeviceCommandMessage>();
            _outbox[mac] = queue;
        }
        queue.Enqueue(new DeviceCommandMessage(commandId, mac, targetState, action, DateTime.UtcNow));
    }

    private void TrimUndoStack()
    {
        if (_undoStack.Count <= MaxUndoDepth) return;
        // Stack<T> cannot drop its bottom item, so rebuild it from the newest MaxUndoDepth entries.
        // Reverse() turns the newest-first enumeration back into push order.
        _undoStack = new Stack<CommandRecord>(_undoStack.Take(MaxUndoDepth).Reverse());
    }

    private void Audit(string kind, string label, string source, int count)
    {
        _audit.AddFirst(new CommandAuditEntry(DateTime.UtcNow, kind, label, source, count));
        while (_audit.Count > MaxAuditEntries) _audit.RemoveLast();
    }

    public static string VerbFor(DeviceKind kind, bool on) => kind switch
    {
        DeviceKind.Valve => on ? "Open" : "Close",
        DeviceKind.WaterPump => on ? "Start" : "Stop",
        _ => on ? "Switch on" : "Switch off"
    };
}
