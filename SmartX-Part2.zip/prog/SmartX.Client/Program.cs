using SmartX.Client.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

var apiBaseAddress = builder.Configuration["SmartXApi:BaseAddress"] ?? "http://localhost:5080";
// Short timeout: a stalled API call should surface as "API unreachable", not freeze the dashboard.
builder.Services.AddScoped(_ => new HttpClient { BaseAddress = new Uri(apiBaseAddress), Timeout = TimeSpan.FromSeconds(8) });
builder.Services.AddScoped<SmartXApiClient>();

// Per-circuit UI state that survives navigation between modules.
builder.Services.AddScoped<DashboardState>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}

app.UseStaticFiles();
app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
