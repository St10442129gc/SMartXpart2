namespace SmartX.Client.Services;

// Client-side shapes of the Part 2 API responses. Enums arrive from the API as strings.

public record DeviceViewDto(
    string MacAddress, string Name, string Kind, string Category, string Location,
    double? LastValue, string Unit, DateTime? LastSeenUtc, bool IsOnline,
    bool IsActuator, bool? ReportedState, bool? DesiredState, bool InSync,
    double? ExpectedMin, double? ExpectedMax, string AlertLevel, string? AlertMessage,
    long PacketsProcessed, int? HealthScore)
{
    public bool? EffectiveState => DesiredState ?? ReportedState;
}

public record QueueStatsDto(int StandardDepth, int PriorityDepth, long TotalStandard, long TotalPriority,
    long DroppedStandard, string? NextPriorityMac);

public record ProcessorStatsDto(bool Paused, int StandardLaneDelayMs, long ProcessedStandard, long ProcessedPriority);

public record FaultStatsDto(int ActiveFaults, int DisconnectedNodes, long SuppressedDuplicateDisconnects, long TotalRaised);

public record ActiveFaultDto(string MacAddress, string Code, DateTime SinceUtc, string Message);

public record ProcessedRecordDto(long Sequence, string MacAddress, string DeviceName, double Value, string Unit,
    string Lane, string Severity, string? Reason, double WaitedMs, DateTime ProcessedUtc, bool ArchivedOnly);

public record SimulatorStatusDto(bool SimulatorConnected, DateTime? LastPollUtc, int Waiting);

public record StreamOverviewDto(
    QueueStatsDto Queue, ProcessorStatsDto Processor, FaultStatsDto Faults,
    List<ActiveFaultDto> ActiveFaults, List<string> DisconnectedNodes,
    int DevicesTotal, int DevicesOnline, int UndoDepth, string? NextUndo,
    List<ProcessedRecordDto> RecentlyProcessed, SimulatorStatusDto Simulator);

public record HistoryPointDto(DateTime TimestampUtc, double Value);

public record DeviceHistoryDto(string MacAddress, string Name, string Unit, double? ExpectedMin, double? ExpectedMax,
    List<HistoryPointDto> Points);

public record StateChangeDto(string MacAddress, string DeviceName, bool? PreviousState, bool NewState);

public record CommandRecordDto(Guid Id, string Action, string Label, string? TargetMac, List<StateChangeDto> Changes,
    DateTime IssuedUtc, string Source);

public record CommandAuditDto(DateTime Utc, string Kind, string Label, string Source, int DevicesAffected);

public record CommandHistoryDto(CommandRecordDto? NextUndo, List<CommandRecordDto> UndoStack, List<CommandAuditDto> Audit);

public record CommandResultDto(bool Ok, string Message, CommandRecordDto? Command);

public record SuggestionDto(string Id, string Kind, string Title, string Detail, string Basis, double Score,
    string Level, string? DeviceMac, string? CommandAction, string? SearchTerm);

public record LearnedPatternDto(string When, string ThenAction, int Count, int Episodes, double Confidence);

public record OperatorEventDto(DateTime Utc, string Kind, string ActionKey, string Label, string? DeviceMac,
    string? CommandAction, bool IsSample);

public record InsightsDto(List<SuggestionDto> SuggestedActions, List<SuggestionDto> AutomatedInsights,
    List<string> HighlightedDevices, List<LearnedPatternDto> LearnedPatterns, List<OperatorEventDto> RecentOperatorEvents);
