using System.Net.Http.Json;

namespace SmartX.Client.Services;

/// <summary>Part 2: Real-Time Command Stream calls.</summary>
public partial class SmartXApiClient
{
    public async Task<StreamOverviewDto?> GetStreamOverviewAsync() =>
        await _http.GetFromJsonAsync<StreamOverviewDto>("/api/stream/overview");

    public async Task<List<DeviceViewDto>> SearchDevicesAsync(string? search, string? category, string? alert)
    {
        var query = new List<string>();
        if (!string.IsNullOrWhiteSpace(search)) query.Add($"search={Uri.EscapeDataString(search)}");
        if (!string.IsNullOrWhiteSpace(category)) query.Add($"category={Uri.EscapeDataString(category)}");
        if (!string.IsNullOrWhiteSpace(alert)) query.Add($"alert={Uri.EscapeDataString(alert)}");
        var url = "/api/stream/devices" + (query.Count > 0 ? "?" + string.Join("&", query) : "");
        return await _http.GetFromJsonAsync<List<DeviceViewDto>>(url) ?? new();
    }

    public async Task<Dictionary<string, double[]>> GetSparklinesAsync(int take = 24) =>
        await _http.GetFromJsonAsync<Dictionary<string, double[]>>($"/api/stream/sparklines?take={take}") ?? new();

    public async Task<DeviceHistoryDto?> GetDeviceHistoryAsync(string mac, int minutes = 10) =>
        await _http.GetFromJsonAsync<DeviceHistoryDto>($"/api/stream/devices/{Uri.EscapeDataString(mac)}/history?minutes={minutes}");

    public async Task<CommandResultDto> IssueCommandAsync(string action, string? mac, string source = "Manual")
    {
        var response = await _http.PostAsJsonAsync("/api/commands", new { Action = action, MacAddress = mac, Source = source });
        return await response.Content.ReadFromJsonAsync<CommandResultDto>()
               ?? new CommandResultDto(false, $"{(int)response.StatusCode} {response.ReasonPhrase}", null);
    }

    public async Task<CommandResultDto> UndoLastCommandAsync()
    {
        var response = await _http.PostAsync("/api/commands/undo", null);
        return await response.Content.ReadFromJsonAsync<CommandResultDto>()
               ?? new CommandResultDto(false, $"{(int)response.StatusCode} {response.ReasonPhrase}", null);
    }

    public async Task<CommandHistoryDto?> GetCommandHistoryAsync() =>
        await _http.GetFromJsonAsync<CommandHistoryDto>("/api/commands/history");

    public async Task<InsightsDto?> GetInsightsAsync() =>
        await _http.GetFromJsonAsync<InsightsDto>("/api/insights");

    /// <summary>Tells the insights engine what the operator searched for, so it can learn search patterns.</summary>
    public async Task RecordSearchAsync(string term) =>
        await _http.PostAsJsonAsync("/api/insights/search", new { Term = term });

    public async Task DismissSuggestionAsync(string id) =>
        await _http.PostAsJsonAsync("/api/insights/dismiss", new { Id = id });

    public async Task<string> LoadSampleOperatorHistoryAsync()
    {
        var response = await _http.PostAsync("/api/insights/train-sample", null);
        var body = await response.Content.ReadFromJsonAsync<Dictionary<string, string>>();
        return body?.GetValueOrDefault("message") ?? "Done.";
    }

    public async Task<bool> RequestScenarioAsync(string type, string? mac = null) =>
        (await _http.PostAsJsonAsync("/api/simulator/scenarios", new { Type = type, MacAddress = mac })).IsSuccessStatusCode;

    public async Task SetProcessingPausedAsync(bool paused) =>
        await _http.PostAsync(paused ? "/api/stream/processing/pause" : "/api/stream/processing/resume", null);

    public async Task SetStandardLaneDelayAsync(int ms) =>
        await _http.PostAsJsonAsync("/api/stream/processing/settings", new { StandardLaneDelayMs = ms });
}
