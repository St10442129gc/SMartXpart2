namespace SmartX.Client.Services;

/// <summary>
/// Per-user (per Blazor circuit) UI state that must survive moving between modules.
///
/// Blazor disposes a page component when you navigate away from it, so anything kept in the page's own fields
/// (a half-typed registration form, the search filter, the device you were charting) would be wiped. Keeping
/// it in this scoped service instead means flipping between Sensor Ingestion and the Command Stream is seamless:
/// you come back to exactly what you left.
/// </summary>
public class DashboardState
{
    // ---- Real-Time Command Stream ----
    public string SearchText { get; set; } = string.Empty;
    public string CategoryFilter { get; set; } = "all";
    public string AlertFilter { get; set; } = "all";
    public string? SelectedDeviceMac { get; set; }
    public int ChartMinutes { get; set; } = 5;
    public string? LastCommandMessage { get; set; }

    // ---- Sensor Ingestion (Part 1) form fields ----
    public string IngestionMac { get; set; } = string.Empty;
    public string IngestionLocation { get; set; } = string.Empty;
    public string IngestionCategory { get; set; } = "Environmental";
    public string? IngestionDeploymentTreeJson { get; set; }
    public string IngestionBatchDeviceId { get; set; } = string.Empty;
    public string IngestionBatchSamplesCsv { get; set; } = "21.1,21.4,45.0,21.3";

    // ---- Shared status shown in the navigation menu ----
    public bool ApiReachable { get; private set; } = true;
    public string? ApiError { get; private set; }
    public int ActiveAlertCount { get; private set; }

    public event Action? Changed;

    public void ReportApiSuccess(int? activeAlerts = null)
    {
        var changed = !ApiReachable || (activeAlerts is not null && activeAlerts != ActiveAlertCount);
        ApiReachable = true;
        ApiError = null;
        if (activeAlerts is not null) ActiveAlertCount = activeAlerts.Value;
        if (changed) Changed?.Invoke();
    }

    public void ReportApiFailure(Exception ex)
    {
        var changed = ApiReachable;
        ApiReachable = false;
        ApiError = ex.GetBaseException().Message;
        if (changed) Changed?.Invoke();
    }
}
