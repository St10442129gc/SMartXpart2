# Smart-X Gateway

An IoT gateway for a network of ESP32 sensors, smart plugs, pumps, relays and valves, built in .NET 8.

- **Part 1 - Sensor Data Ingestion & Telemetry**: register sensors, push typed readings, health scores.
- **Part 2 - Real-Time Command Stream & History**: real-time processing with advanced data structures, manual
  override commands with undo, search/filter, and a predictive action engine.
- **Final PoE - Network Topology & Mesh Routing**: menu entry and placeholder page in place.

| Project | What it is |
|---|---|
| `SmartX.Api` | ASP.NET Core Minimal API - ingestion, processing engine, commands, insights |
| `SmartX.Client` | ASP.NET Core Blazor Server dashboard - the operator console |
| `SmartX.DeviceSimulator` | Console app that pretends to be the device fleet and talks to the API over HTTP (Part 2) |

---

## 1. Prerequisites

- .NET 8 SDK (https://dotnet.microsoft.com/download/dotnet/8.0)
- (Optional) Docker Desktop, to run everything in containers
- Visual Studio 2022 17.8+ or VS Code with the C# Dev Kit

## 2. Restore & build

```bash
dotnet restore SmartX.sln
dotnet build SmartX.sln
```

In Visual Studio: open `SmartX.sln`, let NuGet restore, then Build > Build Solution.

## 3. Run it

### Option A - Docker (everything, one command)

```bash
docker compose up --build
```

Starts three containers: `api` (http://localhost:5080, Swagger at `/swagger`), `client` (http://localhost:5081)
and `simulator` (the device fleet). Open **http://localhost:5081**.

### Option B - three terminals

```bash
# Terminal 1 - API (http://localhost:5080, Swagger at /swagger)
dotnet run --project SmartX.Api

# Terminal 2 - dashboard (http://localhost:5081)
dotnet run --project SmartX.Client

# Terminal 3 - device simulator (registers 12 devices and starts reporting)
dotnet run --project SmartX.DeviceSimulator
```

In Visual Studio: right-click the solution > Configure Startup Projects > Multiple startup projects > set all three
to **Start**.

The simulator takes optional arguments: `dotnet run --project SmartX.DeviceSimulator -- http://localhost:5080 2000`
(API address, reporting interval in ms). When run in a terminal it also accepts keys:
`s` power spike, `m` moisture drop, `d` disconnect, `u` duplicate disconnects, `b` burst, `p` burst + spike,
`r` reconnect, `q` quit.

---

## 4. Navigation

The sidebar lists the three modules. Navigation is asynchronous Blazor routing within one circuit, and the
per-user `DashboardState` service (`SmartX.Client/Services/DashboardState.cs`) holds the search text, filters,
selected device and Part 1 form input. Switching between Sensor Ingestion and the Command Stream and back does
not lose any of it.

Robustness:
- Every polling call is wrapped so an unreachable API shows a banner and a red "API unreachable" status in
  the menu instead of crashing the page. It recovers automatically when the API returns.
- An `ErrorBoundary` in `MainLayout.razor` contains any page exception, so the menu always keeps working.
- The API's background processor catches per-packet errors, so one bad packet never stops processing.

---

## 5. Part 2 - Real-Time Command Stream & History

### 5.1 How data flows

```
Device / simulator ──HTTP──► POST /api/stream/telemetry
                                   │ triage (O(1) Dictionary lookup of the device)
                     ┌─────────────┴──────────────┐
            ordinary reading               critical reading
                     ▼                             ▼
             Queue<T>  (FIFO)          PriorityQueue (critical lane)
                     └─────────────┬──────────────┘
                                   ▼  background StreamProcessor: priority lane is ALWAYS drained first
           Dictionary<MAC, device> ── live state update
           SortedDictionary<DateTime, value> ── timeline history
           HashSet<FaultKey> / HashSet<MAC> ── unique faults, disconnected nodes
           ActionInsightsEngine ── learns, predicts, suggests
```

Commands go the other way: dashboard ──► `POST /api/commands` ──► `Stack<T>` undo history + a per-device FIFO
outbox ──► the device polls `GET /api/stream/devices/{mac}/commands`, applies the command, and reports its new
state in its next telemetry packet.

### 5.2 Where each required data structure lives

Each one is also marked in the source with an `ASSIGNMENT REQUIREMENT (PART 2)` comment header.

| Requirement | Implementation | File |
|---|---|---|
| `Queue<T>` - FIFO telemetry | `_standardLane` | `SmartX.Api/Services/CommandStream/TelemetryIngestionQueue.cs` |
| Priority queue - critical alerts | `_priorityLane` (`PriorityQueue<QueuedPacket, (int, long)>`) | same file |
| `Stack<T>` - command history / undo | `_undoStack` | `SmartX.Api/Services/CommandStream/CommandService.cs` |
| `Dictionary<TKey,TValue>` - live devices by MAC | `_devices` | `SmartX.Api/Services/CommandStream/DeviceRegistry.cs` |
| `SortedDictionary` - timestamped logs | `SortedDictionary<DateTime, double>` per device | `SmartX.Api/Services/CommandStream/TelemetryHistory.cs` |
| `HashSet<T>` - unique errors / disconnected nodes | `_activeFaults`, `_disconnected` | `SmartX.Api/Services/CommandStream/FaultTracker.cs` |
| Processing loop | `StreamProcessor` (hosted `BackgroundService`) | `SmartX.Api/Services/CommandStream/StreamProcessor.cs` |
| Predictive action engine | `ActionInsightsEngine`, `TrendPredictor` | `SmartX.Api/Services/Insights/` |
| Dashboard | Real-Time Command Stream page | `SmartX.Client/Pages/CommandStream.razor` |

### 5.3 The simulated site

The simulator registers 12 devices with ESP32-style MAC addresses. Its physics are linked so that commands have
visible effects:

- **Pump A** waters Hydroponics Bay B: **Moisture Sensor B** slowly dries out unless Pump A is running.
- **Valve 1** feeds Bay A: closing it (e.g. "Shut down all valves") makes **Moisture Sensor A** fall.
- **Heater Plug** draws about 1.2 kW and is the default target for an injected power spike.

The **Test bench** panel at the bottom of the Command Stream page does not fake data inside the API. It parks a
request in `/api/simulator/scenarios`; the simulator picks it up and sends the spike, drop or disconnect as real
device HTTP traffic, so the data goes through exactly the same triage and queues as a physical device would.

---

## 6. How to test each data structure

All steps below use the dashboard at http://localhost:5081/command-stream with the simulator running.
Every one can also be done from Swagger (http://localhost:5080/swagger) - the equivalent call is listed.

### 6.1 Priority queue - simulate a high-priority alert

Critical readings are a smart plug at **2500 W or more**, or a moisture sensor **below 20%**
(configurable under `CommandStream` in `SmartX.Api/appsettings.json`).

**Quick version:** press **⚡ Power spike** or **💧 Moisture drop**. In the **Processing log** the packet appears
with a red **PRIORITY** badge and a wait time of a few milliseconds, the device card turns red, and an
Automated Insight appears.

**Proof that it bypasses the FIFO queue:**
1. Press **⏸ Pause processing**. Packets now pile up; the processor is not taking anything.
2. Press **Burst of ordinary readings**. The **FIFO queue** counter in the status strip climbs to about 100.
3. Press **⚡ Power spike**. The **Priority queue** counter shows 1-2 waiting.
4. Press **▶ Resume processing**. The spike is processed **first**, ahead of every ordinary packet that arrived
   before it: the Priority queue counter drops to 0 immediately while the FIFO queue drains over the next few
   seconds. In the processing log, the spike's sequence number is higher than the FIFO packets around it, yet
   it was handled before them.

The one-click alternative is **Burst + spike**, which sends about 70 ordinary readings followed by one spike. To
make the backlog last longer, raise **FIFO cost per packet**. This is the simulated processing time per ordinary
packet on a constrained gateway, default 60 ms; critical packets never pay it.

Swagger: `POST /api/stream/processing/pause`, then post several readings and one critical reading to
`POST /api/stream/telemetry`, e.g.
```json
{ "macAddress": "50:02:91:B2:00:02", "value": 3400 }
```
then `POST /api/stream/processing/resume` and `GET /api/stream/overview` → `recentlyProcessed`.
The telemetry response already tells you which lane the packet went into: `"lane": "Priority"`.

### 6.2 Queue&lt;T&gt; - FIFO processing

With processing running, watch the **Processing log**: ordinary packets come out in increasing sequence order,
first in first out. Their **Waited** time grows while a backlog exists, which you can see by pressing
**Burst of ordinary readings**. `GET /api/stream/overview` → `queue.standardDepth` shows the live queue length.

### 6.3 Stack&lt;T&gt; - command history and Undo

1. Press **Shut down all valves**. All three valves turn CLOSED, and the command appears at the top of the
   **Undo stack** in Command history.
2. Switch a single device, e.g. **Start** on Pump A. That command is now on top.
3. Press **↶ Undo**. The most recent command (Pump A) is reverted first: last in, first out.
4. Press **↶ Undo** again. "Shut down all valves" is reverted, and every valve goes back to the state *it* was
   in before, so a valve that was already closed stays closed.

The Undo button always shows which command it will revert (`Stack.Peek()`), and the audit trail records every
issue and undo. Watch the device cards show "syncing…" until the simulated device polls, applies the command and
reports back. Swagger: `POST /api/commands` with `{ "action": "ShutdownAllValves" }`, then `POST /api/commands/undo`.
Supported actions: `TurnOn`, `TurnOff`, `Toggle` (with `macAddress`), `ShutdownAllValves`, `OpenAllValves`, `StopAllPumps`.

### 6.4 Dictionary&lt;TKey,TValue&gt; - O(1) device lookup by MAC

Every incoming packet is matched to its device with a single `Dictionary` lookup on the MAC address, in
`TelemetryIngestionQueue.Enqueue` and `StreamProcessor.Process`. To see it:
- `GET /api/stream/devices/24:6F:28:C3:00:01` returns Pump A directly by key.
- Post telemetry for an unregistered MAC to `POST /api/stream/telemetry`: the lookup misses and the API answers
  404 straight away.
- The **Devices online** counter is the dictionary's size.

### 6.5 SortedDictionary - timeline history

Click any device card to open its **Timeline** graph, which is read straight off the `SortedDictionary` keys
(`GET /api/stream/devices/{mac}/history`).

The sorting matters for this reason. In the pause → burst → spike → resume test, the spike is processed *before*
older readings. A plain list would end up out of order, but because readings are keyed by the device's own
timestamp they slot into the correct place. Those older readings show as **· late** in the processing log: they
are archived into history without overwriting the newer live value.

### 6.6 HashSet&lt;T&gt; - unique errors, no duplicate disconnect alerts

Press **5× duplicate disconnects**. The node sends five identical "link lost" alerts, but only the first one is
accepted (`HashSet.Add` returns true). The other four are rejected as duplicates, so **Duplicates suppressed**
in the status strip goes up by 4 and only one fault is raised. Press **Reconnect all** to bring it back.

Swagger: call `POST /api/stream/devices/24:6F:28:D4:00:03/disconnect` repeatedly. The first response says
`"alertRaised": true` and every later one says `"alertRaised": false`.
A silent device is also caught by the heartbeat watchdog after 15 seconds; try **Disconnect node** and watch
the card go dashed and OFFLINE.

### 6.7 Search and filter

Use the search box (name, MAC, location or device type), the **category** filter (Environmental / Power
consumption / Actuators) and the **alert state** filter (has an alert, critical, warning, disconnected, healthy).
Results update as you type. Pressing **Enter** or **Search** also reports the search to the suggestion engine so
it can learn from it. `GET /api/stream/devices?search=pump&category=Actuator&alert=all`.

---

## 7. Predictive Action & Recommendation Engine

`SmartX.Api/Services/Insights/ActionInsightsEngine.cs` produces two lists, shown on the dashboard as
**✨ Suggested Actions** and **🔎 Automated Insights**.

**Suggested Actions are learned from your behaviour:**
- **Pattern analysis (condition → action rules).** Every search and command is credited to each fault that is
  active at that moment, counted once per fault episode. Over time this builds rules such as
  *"Moisture Sensor B below 20% → search Pump A → start Pump A"*, with
  `confidence = times you did it ÷ times the condition occurred`. When that condition happens again, the action
  is suggested before you search for it, with a one-click **Do it**. A rule needs at least 2 occurrences.
  Suggestions that are already satisfied are hidden; for example, "Start Pump A" is not offered if the pump is
  already running.
- **Sequence analysis (Markov chain).** It also counts which action tends to follow which, so after one step
  it can suggest the usual next one.

**Automated Insights flag problem devices from live data, with no training needed:**
- offline nodes and active critical faults, taken from the HashSets;
- a **trend forecast**, which fits a least-squares line over each sensor's recent SortedDictionary history and
  warns before a reading crosses its safe band (e.g. "Moisture Sensor B predicted to drop below 30% in ~40 s");
- **recurring faults**, for a device that has faulted 3 or more times.

Flagged devices get a ⚑ and a red tint on their card. All candidates are ranked through a
`PriorityQueue<Suggestion, double>`, so only the most relevant few are shown.

### How to test it

**Live learning, about 2 minutes:**
1. Press **💧 Moisture drop**, which makes Moisture Sensor B drop below 20%.
2. Type `Pump A` in the search box and press Enter, then press **Start** on Pump A's card.
3. Wait for Moisture B to recover (Pump A waters it), then press **Stop** on Pump A.
4. Repeat steps 1-3 once more.
5. Press **💧 Moisture drop** a third time. Before you search for anything, **Suggested Actions** shows
   **"Start Pump A"** and **"Check Pump A"**. Press **Do it**.

The **Learned patterns** table shows the rules and their confidence as they form, and **Recent operator
activity** shows what the engine is learning from.

**Instant version:** press **Load sample operator history**, which loads three past episodes of that pattern, then
press **💧 Moisture drop**.

---

## 8. Part 1 features (still available)

Open **Sensor Data Ingestion & Telemetry** in the menu:
- Register a sensor (MAC address, location, category). It is also added to the Part 2 device registry.
- Health-score cards (the dynamic engagement feature): clean readings raise the score and streak, while
  anomalies and disconnects drop it. Devices reporting through the Part 2 stream update these scores too.
- Attach a config file, photo or log to a sensor. It is AES-256 encrypted at rest and decrypted on download.
- The live telemetry feed includes simulator traffic.
- Demo panels for operator overloading (`SensorReading` `+ - > < ==`), jagged array → `List<T>` batch loading,
  and recursive deployment-tree validation.

| Part 1 requirement | File |
|---|---|
| Generics (`TelemetryPacket<T>`) | `SmartX.Api/Models/TelemetryPacket.cs` |
| Operator overloading | `SmartX.Api/Models/SensorModels.cs` |
| Jagged arrays → `List<T>` | `SmartX.Api/Services/TelemetryStore.cs` (`IngestBatch`) |
| Recursion | `SmartX.Api/Models/DeploymentNode.cs` |
| Dynamic engagement feature | `SmartX.Api/Services/HealthScoreService.cs` |
| Custom collection | `SmartX.Api/Models/TelemetryArchive.cs` |
| Encryption at rest | `SmartX.Api/Services/FileEncryptionService.cs` |

---

## 9. API reference (Part 2)

Full contract in Swagger at http://localhost:5080/swagger.

| Method & route | Purpose |
|---|---|
| `POST /api/stream/devices` | Device registers itself (idempotent by MAC) |
| `POST /api/stream/telemetry` | Device reports a reading → triaged into the FIFO or priority lane (202) |
| `POST /api/stream/devices/{mac}/disconnect` | Device reports a lost link (duplicates suppressed) |
| `GET  /api/stream/devices/{mac}/commands` | Device polls for its override commands (FIFO) |
| `GET  /api/stream/devices?search=&category=&alert=` | Search / filter devices |
| `GET  /api/stream/devices/{mac}/history?minutes=` | Timeline from the SortedDictionary |
| `GET  /api/stream/overview` | Queue depths, processor stats, faults, processing log |
| `POST /api/stream/processing/pause` · `/resume` · `/settings` | Pause/resume processing, set FIFO cost per packet |
| `POST /api/commands` · `POST /api/commands/undo` · `GET /api/commands/history` | Overrides, undo, undo stack + audit |
| `GET  /api/insights` | Suggested actions, automated insights, learned patterns |
| `POST /api/insights/search` · `/dismiss` · `/train-sample` | Record a search, hide a suggestion, load sample history |
| `POST /api/simulator/scenarios` · `GET /api/simulator/scenarios/next` | Test-bench mailbox for the simulator |

## 10. Troubleshooting

- **No devices on the Command Stream page:** the simulator is not running. Start it with
  `dotnet run --project SmartX.DeviceSimulator`; the pill at the top right says "Simulator connected" once it is.
- **"API unreachable" in the menu:** start `SmartX.Api` first. The dashboard reconnects by itself.
- **Missing Swashbuckle / AddSwaggerGen errors:** restore NuGet packages for `SmartX.Api` (it references
  `Swashbuckle.AspNetCore`).
- **Different ports:** the client reads the API address from `SmartX.Client/appsettings.json`
  (`SmartXApi:BaseAddress`); the simulator takes it as its first argument or the `SMARTX_API` variable.

## 11. Video demo

[Add your video link here once recorded]
